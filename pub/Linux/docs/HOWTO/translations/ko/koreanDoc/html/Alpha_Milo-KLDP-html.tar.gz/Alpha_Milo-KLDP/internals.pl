# LaTeX2HTML 98.1p1 release (March 2nd, 1998)
# Associate internals original text with physical files.


$key = q/cite_1/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_2/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

1;


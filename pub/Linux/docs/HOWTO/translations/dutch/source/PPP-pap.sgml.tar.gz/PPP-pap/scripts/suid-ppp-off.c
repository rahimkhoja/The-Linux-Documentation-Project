#include <unistd.h>
void main()
{
	setreuid(0, 0);
	execl("/usr/local/sbin/ppp-off", "", "");
}

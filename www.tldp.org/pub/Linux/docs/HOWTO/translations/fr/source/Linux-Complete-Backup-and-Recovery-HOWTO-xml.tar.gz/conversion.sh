#!/bin/bash

echo -n "<![CDATA[" > "$2"
cat "$1" >> "$2"
echo "]]>" >> "$2"


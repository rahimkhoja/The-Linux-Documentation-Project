#/bin/sh -e

echo "Pr�paration du dossier inclusion"

rm -rf inclusions
mkdir -p inclusions
for i in scripts/* ; do
    ./conversion.sh "$i" "inclusions/`basename \"$i\"`" ;
done

echo "Pr�paration du dossier outils"

rm -rf outils/Linux-Complete-Backup-and-Recovery-HOWTO/
mkdir -p outils/Linux-Complete-Backup-and-Recovery-HOWTO/
cp -R scripts/* outils/Linux-Complete-Backup-and-Recovery-HOWTO/


echo "Fini"
